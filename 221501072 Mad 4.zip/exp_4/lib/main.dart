import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Student Details',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _formKey = GlobalKey<FormState>();
  String? _regNo;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Enter Reg No.'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                'Please enter your registration number',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              TextFormField(
                decoration: InputDecoration(labelText: 'Reg No'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your registration number';
                  }
                  return null;
                },
                onSaved: (value) {
                  _regNo = value;
                },
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState?.validate() ?? false) {
                    _formKey.currentState?.save();
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => DetailsPage(regNo: _regNo),
                      ),
                    );
                  }
                },
                child: Text('VIEW STUDENT DETAILS'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class DetailsPage extends StatelessWidget {
  final String? regNo;

  DetailsPage({required this.regNo});

  final Map<String, Map<String, String>> studentData = {
    '90': {
      'NAME': 'Nithya Shree AK',
      'DEPT': 'AIML',
      'SEC': 'B',
      'ADDRESS': '71 Netaji Salai, Tiruvallur',
      'COLLEGE NAME': 'Rajalakshmi Engineering College',
      'BLOOD GROUP': 'O+',
      'DOB': '28/10/2003',
      'PHONE NUMBER': '9025534662',
    },
    '77': {
      'NAME': 'Menakss',
      'DEPT': 'AIML',
      'SEC': 'B',
      'ADDRESS': '13 GANDI NAGAR ENOORE',
      'COLLEGE NAME': 'REC',
      'BLOOD GROUP': 'A2+',
      'DOB': '09/10/2004',
      'PHONE NUMBER': '6365676890',
    },
    '1': {
      'NAME': 'John Doe',
      'DEPT': 'CSE',
      'SEC': 'A',
      'ADDRESS': '123 Main St, City',
      'COLLEGE NAME': 'Tech University',
      'BLOOD GROUP': 'B+',
      'DOB': '01/01/2000',
      'PHONE NUMBER': '1234567890',
    },
    '2': {
      'NAME': 'Jane Smith',
      'DEPT': 'ECE',
      'SEC': 'B',
      'ADDRESS': '456 Elm St, City',
      'COLLEGE NAME': 'Engineering College',
      'BLOOD GROUP': 'A-',
      'DOB': '02/02/2001',
      'PHONE NUMBER': '2345678901',
    },
    '3': {
      'NAME': 'Alice Johnson',
      'DEPT': 'IT',
      'SEC': 'C',
      'ADDRESS': '789 Oak St, City',
      'COLLEGE NAME': 'Innovation Institute',
      'BLOOD GROUP': 'O-',
      'DOB': '03/03/2002',
      'PHONE NUMBER': '3456789012',
    },
    '4': {
      'NAME': 'Bob Brown',
      'DEPT': 'EEE',
      'SEC': 'D',
      'ADDRESS': '321 Pine St, City',
      'COLLEGE NAME': 'Future College',
      'BLOOD GROUP': 'AB+',
      'DOB': '04/04/2003',
      'PHONE NUMBER': '4567890123',
    },
    '5': {
      'NAME': 'Carol White',
      'DEPT': 'MCE',
      'SEC': 'E',
      'ADDRESS': '654 Cedar St, City',
      'COLLEGE NAME': 'Progress University',
      'BLOOD GROUP': 'B-',
      'DOB': '05/05/2004',
      'PHONE NUMBER': '5678901234',
    },
    '6': {
      'NAME': 'David Lee',
      'DEPT': 'BME',
      'SEC': 'F',
      'ADDRESS': '987 Birch St, City',
      'COLLEGE NAME': 'Excellence Institute',
      'BLOOD GROUP': 'A+',
      'DOB': '06/06/2005',
      'PHONE NUMBER': '6789012345',
    },
    '7': {
      'NAME': 'Eva Adams',
      'DEPT': 'CIV',
      'SEC': 'G',
      'ADDRESS': '432 Spruce St, City',
      'COLLEGE NAME': 'Pinnacle College',
      'BLOOD GROUP': 'O+',
      'DOB': '07/07/2006',
      'PHONE NUMBER': '7890123456',
    },
    '8': {
      'NAME': 'Frank Green',
      'DEPT': 'CHE',
      'SEC': 'H',
      'ADDRESS': '567 Fir St, City',
      'COLLEGE NAME': 'Summit University',
      'BLOOD GROUP': 'AB-',
      'DOB': '08/08/2007',
      'PHONE NUMBER': '8901234567',
    },
    '9': {
      'NAME': 'Grace Turner',
      'DEPT': 'PHY',
      'SEC': 'I',
      'ADDRESS': '890 Maple St, City',
      'COLLEGE NAME': 'Harvard College',
      'BLOOD GROUP': 'A+',
      'DOB': '09/09/2008',
      'PHONE NUMBER': '9012345678',
    },
    '10': {
      'NAME': 'Henry Scott',
      'DEPT': 'BIO',
      'SEC': 'J',
      'ADDRESS': '123 Oak St, City',
      'COLLEGE NAME': 'Stanford University',
      'BLOOD GROUP': 'B-',
      'DOB': '10/10/2009',
      'PHONE NUMBER': '0123456789',
    },
  };

  @override
  Widget build(BuildContext context) {
    final student = studentData[regNo] ??
        {
          'NAME': 'Unknown',
          'DEPT': 'Unknown',
          'SEC': 'Unknown',
          'ADDRESS': 'Unknown',
          'COLLEGE NAME': 'Unknown',
          'BLOOD GROUP': 'Unknown',
          'DOB': 'Unknown',
          'PHONE NUMBER': 'Unknown',
        };

    return Scaffold(
      appBar: AppBar(
        title: Text('Student Details'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            DetailRow(label: 'NAME', value: student['NAME']!),
            DetailRow(label: 'DEPT', value: student['DEPT']!),
            DetailRow(label: 'SEC', value: student['SEC']!),
            DetailRow(label: 'ADDRESS', value: student['ADDRESS']!),
            DetailRow(label: 'COLLEGE NAME', value: student['COLLEGE NAME']!),
            DetailRow(label: 'BLOOD GROUP', value: student['BLOOD GROUP']!),
            DetailRow(label: 'DOB', value: student['DOB']!),
            DetailRow(label: 'PHONE NUMBER', value: student['PHONE NUMBER']!),
          ],
        ),
      ),
    );
  }
}

class DetailRow extends StatelessWidget {
  final String label;
  final String value;

  DetailRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: <Widget>[
          Text(
            '$label : ',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          SizedBox(width: 10),
          Expanded(
            child: Text(value),
          ),
        ],
      ),
    );
  }
}
