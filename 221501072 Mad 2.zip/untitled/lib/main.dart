import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:fluttertoast/fluttertoast.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Hello Nithya App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HelloNithyaPage(),
    );
  }
}

class HelloNithyaPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Display the toast message
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Fluttertoast.showToast(
        msg: "Your desired font and color is displayed",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.black54,
        textColor: Colors.white,
        fontSize: 16.0,
      );
    });

    return Scaffold(
      appBar: AppBar(
        title: Text('Hello Nithya Page'),
      ),
      body: Center(
        child: Text(
          'Hello Nithya',
          style: GoogleFonts.lobster(
            textStyle: TextStyle(
              color: Colors.purple,
              fontSize: 36.0, // Enlarged font size
            ),
          ),
        ),
      ),
    );
  }
}
