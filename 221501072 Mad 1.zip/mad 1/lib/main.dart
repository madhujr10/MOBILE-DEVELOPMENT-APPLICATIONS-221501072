import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter SQLite',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _formKey = GlobalKey<FormState>();
  String? _name;
  String? _regNo;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Flutter SQLite'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                'Please enter your details',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              TextFormField(
                decoration: InputDecoration(labelText: 'Name'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your name';
                  }
                  return null;
                },
                onSaved: (value) {
                  _name = value;
                },
              ),
              TextFormField(
                decoration: InputDecoration(labelText: 'Reg No'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your registration number';
                  }
                  return null;
                },
                onSaved: (value) {
                  _regNo = value;
                },
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState?.validate() ?? false) {
                    _formKey.currentState?.save();
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ResultsPage(name: _name, regNo: _regNo),
                      ),
                    );
                  }
                },
                child: Text('GET RESULTS'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ResultsPage extends StatelessWidget {
  final String? name;
  final String? regNo;

  ResultsPage({this.name, this.regNo});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Results'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              'Select Semester',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            ListTile(
              title: Text('Semester 1'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => SemesterResults(
                      semester: 1,
                      subjects: ['Electronics', 'C Language', 'Math 1', 'Physics', 'Chemistry'],
                      grades: ['A', 'B', 'A', 'B', 'A'],
                      gpa: 8.3,
                    ),
                  ),
                );
              },
            ),
            ListTile(
              title: Text('Semester 2'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => SemesterResults(
                      semester: 2,
                      subjects: ['Data Structures', 'OOP', 'Math 2', 'Digital Logic', 'Discrete Math'],
                      grades: ['A', 'A', 'B', 'A', 'B'],
                      gpa: 9.0,
                    ),
                  ),
                );
              },
            ),
            ListTile(
              title: Text('Semester 3'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => SemesterResults(
                      semester: 3,
                      subjects: ['Database Systems', 'Operating Systems', 'Algorithms', 'Computer Networks', 'Software Engineering'],
                      grades: ['A', 'A', 'A', 'B', 'A'],
                      gpa: 9.0,
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class SemesterResults extends StatelessWidget {
  final int semester;
  final List<String> subjects;
  final List<String> grades;
  final double gpa;

  SemesterResults({required this.semester, required this.subjects, required this.grades, required this.gpa});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Semester $semester Results'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Expanded(
              child: ListView.builder(
                itemCount: subjects.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(subjects[index]),
                    trailing: Text(grades[index]),
                  );
                },
              ),
            ),
            Text(
              'GPA: $gpa',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => DetailsPage(),
                  ),
                );
              },
              child: Text('VIEW DETAILS'),
            ),
          ],
        ),
      ),
    );
  }
}

class DetailsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Details'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text('NAME: Nithya Shree AK', style: TextStyle(fontSize: 16)),
            Text('DEPT: AIML', style: TextStyle(fontSize: 16)),
            Text('SEC: B', style: TextStyle(fontSize: 16)),
            Text('ADDRESS: 71 Netaji Salai, Tiruvallur', style: TextStyle(fontSize: 16)),
            Text('COLLEGE NAME: Rajalakshmi Engineering College', style: TextStyle(fontSize: 16)),
            Text('BLOOD GROUP: O+', style: TextStyle(fontSize: 16)),
            Text('DOB: 28/10/2003', style: TextStyle(fontSize: 16)),
            Text('PHONE NUMBER: 9025534662', style: TextStyle(fontSize: 16)),
          ],
        ),
      ),
    );
  }
}
